<?php
session_start();

// Hardcoded credentials
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'password123');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($username === ADMIN_USERNAME && $password === ADMIN_PASSWORD) {
        $_SESSION['admin_logged_in'] = true;
        header('Location: admin_dashboard.php');
        exit;
    } else {
        $error = 'Invalid username or password.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Admin Login</title>
<style>
    /* Reset some default styles */
    * {
        box-sizing: border-box;
    }
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f0f2f5;
        margin: 0;
        padding: 0;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .login-container {
        background-color: white;
        padding: 40px 60px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        width: 360px;
        text-align: center;
    }

    /* VB Logo */
    .logo-vb {
        font-weight: 900;
        font-size: 48px;
        color: #1877f2;
        font-family: 'Segoe UI Black', 'Arial Black', Arial, sans-serif;
        letter-spacing: -4px;
        margin-bottom: 30px;
        user-select: none;
    }
    /* Optional subtle shadow for depth */
    .logo-vb {
        text-shadow: 1px 1px 2px rgba(24, 119, 242, 0.5);
    }

    form {
        display: flex;
        flex-direction: column;
    }

    input[type="text"], input[type="password"] {
        height: 44px;
        margin-bottom: 14px;
        padding: 0 12px;
        font-size: 17px;
        border: 1px solid #dddfe2;
        border-radius: 6px;
        outline: none;
        transition: border-color 0.3s;
    }

    input[type="text"]:focus, input[type="password"]:focus {
        border-color: #1877f2;
        box-shadow: 0 0 0 2px rgba(24, 119, 242, 0.2);
    }

    button {
        background-color: #1877f2;
        border: none;
        border-radius: 6px;
        color: white;
        font-size: 20px;
        font-weight: 600;
        height: 44px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    button:hover {
        background-color: #165ec9;
    }

    .error-message {
        color: #f02849;
        margin-bottom: 14px;
        text-align: center;
        font-weight: 600;
    }

    .footer-text {
        font-size: 12px;
        color: #65676b;
        text-align: center;
        margin-top: 30px;
    }

    .footer-text a {
        color: #1877f2;
        text-decoration: none;
    }

    .footer-text a:hover {
        text-decoration: underline;
    }

    /* Responsive */
    @media (max-width: 400px) {
        .login-container {
            width: 90%;
            padding: 30px 20px;
        }
    }
</style>
</head>
<body>
    <div class="login-container">
        <!-- VB Letter Logo -->
        <div class="logo-brazzel">BRAZZEL</div>

        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <input type="text" name="username" placeholder="Email or Phone Number" required autofocus />
            <input type="password" name="password" placeholder="Password" required />
            <button type="submit">Log In</button>
        </form>

        <div class="footer-text">
            <a href="#">Forgotten password?</a>
        </div>
    </div>
</body>
</html>
