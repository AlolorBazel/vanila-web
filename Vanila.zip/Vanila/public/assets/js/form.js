function UserValidator (firsname,midname,lastname,email,contact,batch,idnum,technology){

    let isValid = true;

    if (!/^[a-zA-Z\s-]+$/.test(firsname)){
        return "Firstname contains only alphabets.";
    }




            // Handle form submission
            function submitForm() {
                var firstName = document.getElementById("firstName").value;
                var lastName = document.getElementById("lastName").value;
    
                var validationMessage = validateName(firstName, lastName);
    
                document.getElementById("result").textContent = validationMessage;
            }

}